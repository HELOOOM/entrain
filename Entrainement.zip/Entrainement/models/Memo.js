const {default:mongoose}=require('mongoose');


const schema = new mongoose.Schema({

    date:{
        type:String,
        require:true
    },
    content:{
        type:String,
        require:true
    }

})

const Memo=mongoose.model("memos",schema)

module.exports={schemaMemo:schema,Memo:Memo}