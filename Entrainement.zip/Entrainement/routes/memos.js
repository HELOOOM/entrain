const { json } = require('express');
const express= require('express')
const {Memo} = require('../models/Memo');
const router = express.Router();



//get
router.get("",async(req,res)=>{
    // const login =  req.session.login;
    // const user=await User.findOne({login:login})
    const memos= await Memo.find();
    const nbr=req.query.nbr || memos.length
    if(nbr)
        res.json(memos.filter((elem,index)=>index<nbr));
    else
        res.json(await Memo.find());

            // res.json(memos);
       
})
router.get("/:id",async(req,res)=>{
  
    const {id}=req.params
    try{
        const result=await Memo.findById(id)
        res.status(200).json({message : "find it!!",result})
    }catch(err){
        res.status(500).json({message:"err",err})
    } 
   

          
       
})


// ajouter
router.post("",async (req,res)=>{

    // recuperation des donnees envoyees
   const {date, content} =  req.body
   // verification
   if(!date || !content)
    return res.status(400).json({message:"date and content are required"})

    // creer une instance du model
    const memo=new Memo({
        date:date,
        content:content
    })
    
    try{
    
    const dataMemo =  await memo.save()
    res.json(dataMemo);

    }catch(err)
    {
        res.status(500).send({message:err})
    }


   
})

// lister

  

// selectionner


// modifier

router.put("/:idMemo", async (req,res)=>{

    const  idMemo = req.params.idMemo
    const { date, content } = req.body
    try {

        const result = await  Memo.findByIdAndUpdate(idMemo, { date, content })
        res.status(200).json({ message: "memo updated", result })

    }
    catch (err) {
        res.status(500).json({ message: "error", err })
    }
})


//supprimer ( method utilise en http : delete. l identifiant de la ressource doit etre dournie au niveau du URL)
// delete localhost:30000/memos/1245
router.delete("/:idMemo",async (req,res)=>{

    const idMemo=req.params.idMemo
    Memo.findByIdAndDelete(idMemo).then(()=>{
        res.json({msg:'removed successfuly'})
       }).catch(err=>res.status(500).json({err:err.message}))
})



module.exports.memosRouter= router;