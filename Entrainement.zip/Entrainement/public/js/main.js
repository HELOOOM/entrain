import {addBtn, memoInput, tbody} from "./config.js"
import { addMemo, deleteMemo,load} from "./memos.js";

load();
addBtn.addEventListener('click',()=>{
    const content=memoInput.value
    if(!content)
        return alert("please provide a content for your memo")
    
    addMemo(content)
})


export const addMemoToTable=(memo)=>{
    const {date,content,_id} = memo

    // creation des elemments
    const tr= document.createElement("tr")
    const td1= document.createElement("td")
    const td2= document.createElement("td")
    const td3= document.createElement("td")
    const td4= document.createElement("td")
    const btn= document.createElement("button")

    // liaison parent.appendChild(fils)
    tr.appendChild(td1)
    tr.appendChild(td2)
    tr.appendChild(td3)
    tr.appendChild(td4)
    td4.appendChild(btn)

    tr.setAttribute("id",_id);
    //remplissage
    td1.innerText=_id
    td2.innerText=content
    td3.innerText=date
    btn.innerText="delete"

    btn.classList.add("delete")
    btn.addEventListener("click",()=>{
        //TODO : call fetch delete + delete row
        deleteMemo(_id)
    })

    tbody.appendChild(tr)
}