export const url=" http://localhost:3000"


export const memoInput = document.getElementById("memoInput");
export const addBtn = document.getElementById("addBtn");
export const tbody = document.getElementById("tbody");




