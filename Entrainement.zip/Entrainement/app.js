const mongoose=require("mongoose")
const express=require("express")
const dotenv=require("dotenv")
mongoose.set('strictQuery', false);
const { memosRouter } = require('./routes/memos')

dotenv.config();

//mongoose

mongoose.connect
(process.env.chaine_connection)
.then(()=>console.log("connected to mongodb atlas"))
.catch(err=>console.log(err))

//express

const app=express();
app.use(express.json())
app.use(express.static("./public"))
app.use('/memos',memosRouter)

const port =process.env.port || 3000
app.listen(port, ()=>{
    console.log('server listening on port : ',port)
})